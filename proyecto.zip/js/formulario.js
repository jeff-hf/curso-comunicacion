'use strict';

const nombre = document.querySelector('#user_name');
const gmail = document.querySelector('#user_email');
const privincia = document.querySelector('#direction');
const telefono = document.querySelector('#phone');
const mensaje = document.querySelector('#message');

(function() {
    emailjs.init('user_ljzCG7QYXdkFT9wZCL4wG');
})();

window.onload = function() {
    document.getElementById('contact-form').addEventListener('submit', function(event) {
        let nombre_cliente = nombre.value;
        let correo = gmail.value;
        event.preventDefault();
        this.contact_number.value = Math.random() * 100000 | 0;
        emailjs.send("service_pqeij22", "template_f66c1bc", {
                from_name: "maderasalfaro587@gmail.com",
                to_name: `${nombre_cliente},[${correo}]`,
                direction: 'Lopez Mateo, San Sebastán, CR',
                phone: '22262325',
                message: "Muchas gracias por ponerte en contacto con nosotros, pronto responderemos a tu consulta",
            })
            .then(function() {
                Swal.fire({
                    icon: 'success',
                    title: 'Enviando...',
                    html: 'Correo enviado con exito',
                })
                console.log('SUCCESS!');
                limpiar()
            }, function(error) {
                console.log('FAILED...', error);
            });
    });
}

const limpiar = () => {
    gmail.value = '';
    nombre.value = '';
    privincia.value = '';
    telefono.value = '';
    mensaje.value = '';
};