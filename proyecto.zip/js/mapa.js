mapboxgl.accessToken = 'pk.eyJ1IjoiamVmZmhmIiwiYSI6ImNrODRtYXBqdDAyOXozZ3F1dWtqaHZsczYifQ.rArKNiFci3wV3Sx0xnrcIg';
const map = new mapboxgl.Map({
    container: 'map',
    style: 'mapbox://styles/mapbox/streets-v11',
    center: [-84.093339, 9.905784],
    zoom: 16
});

const popup = new mapboxgl.Popup({ offset: 25 }).setText(
    'Trabajos en madera Alfaro, Lopez Mateo, San Sebastián.'
);

const marker = new mapboxgl.Marker()
    .setLngLat([-84.093339, 9.905784])
    .setPopup(popup)
    .addTo(map);